3. Opinion Poll
Using the Person class, write a program that reads from the console N lines of personal information and then prints all people whose age is more than 30 years.

Examples:

Input 1:
3
Peter 12
Sam 31
Itan 48

Output 1:
Sam - 31
Itan - 48

Input 2:
5
Niko 33
Yana 88
Todor 22
Lisa 44
Sam 11

Output 2:
Niko - 33
Yana - 88
Lisa - 44