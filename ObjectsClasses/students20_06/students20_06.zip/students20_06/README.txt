5. Students
Use the class from the previous problem. If you receive a student which already exists (first name and last name should be unique) overwrite the information.

"" Previous problem:
Define a class Student, which holds the following information about students: first name, last name, age, and hometown. 
Read the list of students until you receive the "end" command. After that, you will receive a city name. Print only students which are from the given city, in the following format: "{firstName} {lastName} is {age} years old".
""

Examples:

Input 1:
John Smith 15 Sofia
John Smith 16 Sofia
Linda Bridge 17 Sofia
Simon Stone 12 Varna
end
Sofia

Output 1:
John Smith is 16 years old
Linda Bridge is 17 years old

Input 2:
J S 3 S
Peter Ivanov 14 P
P J 104 S
J P 61 S
Simon Stone 12 Varna
Simon Sone 12 Varna
end
Varna

Output 2:
Simon Stone is 12 years old
Simon Sone is 12 years old