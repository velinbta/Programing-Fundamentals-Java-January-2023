4. Students
Write a program that receives n count of students and orders them by grade (in descending). Each student should have a first name (string), last name (string), and grade (a floating-point number). 

Input
First-line will be a number n.
Next n lines you will get a student info in the format "{first name} {second name} {grade}".

Output
Print each student in the following format "{first name} {second name}: {grade}".

Examples:

Input 1:
4
Lakia Eason 3.90
Prince Messing 5.49
Akiko Segers 4.85
Rocco Erben 6.00

Output 1:
Rocco Erben: 6.00
Prince Messing: 5.49
Akiko Segers: 4.85
Lakia Eason: 3.90

Input 2:
4
Sydnie Britton 5.79
Amias Mathews 2.30
Mora Tod 2.78
Pete Kendrick 2.61

Output 2:
Sydnie Britton: 5.79
Mora Tod: 2.78
Pete Kendrick: 2.61
Amias Mathews: 2.30