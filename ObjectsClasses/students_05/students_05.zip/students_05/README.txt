5. Students
Define a class Student, which holds the following information about students: first name, last name, age, and hometown. 
Read the list of students until you receive the "end" command. After that, you will receive a city name. Print only students which are from the given city, in the following format: "{firstName} {lastName} is {age} years old".

Examples:

Input 1:
John Smith 15 Sofia
Peter Ivanov 14 Plovdiv
Linda Bridge 16 Sofia
Simon Stone 12 Varna
end
Sofia

Output 1:
John Smith is 15 years old
Linda Bridge is 16 years old

Input 2:
Anthony Taylor 15 Chicago
David Anderson 16 Washington
Jack Lewis 14 Chicago
David Lee 14 Chicago
end
Chicago

Output 2:
Anthony Taylor is 15 years old
Jack Lewis is 14 years old
David Lee is 14 years old