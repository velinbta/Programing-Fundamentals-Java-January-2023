1. Advertisement Message
Write a program that generates random fake advertisement messages to extol some product. The messages must consist of 4 parts: laudatory phrase + event + author + city. Use the following predefined parts:

Phrases - {"Excellent product.", "Such a great product.", "I always use that product.", "Best product of its category.", "Exceptional product.", "I can't live without this product."}

Events - {"Now I feel good.", "I have succeeded with this product.", "Makes miracles. I am happy of the results!", "I cannot believe but now I feel awesome.", "Try it yourself, I am very satisfied.", "I feel great!"}

Authors - {"Diana", "Petya", "Stella", "Elena", "Katya", "Iva", "Annie", "Eva"}

Cities - {"Burgas", "Sofia", "Plovdiv", "Varna", "Ruse"}

The format of the output message is: {phrase} {event} {author} - {city}.
As an input, you take the number of messages to be generated. Print each random message on a separate line.

Examples:

Input 1:
3

Output 1:
Such a great product. Now I feel good. Elena - Ruse
Excelent product. Makes miracles. I am happy of the results! Katya - Varna
Best product of its category. That makes miracles. Eva - Sofia

Input 2:
4

Output 2:
I always use that product. Makes miracles. I am happy of the results! Iva - Ruse
I can't live without this product. I cannot believe but now I feel awesome. Katya - Burgas
Such a great product. Try it yourself, I am very satisfied. Iva - Varna
Best product of its category. I cannot believe but now I feel awesome. Eva - Ruse